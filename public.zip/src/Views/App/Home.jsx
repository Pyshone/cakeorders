import React from 'react'
import Login from '../../Components/Section/Home/Login'
import Validateform from '../../Components/Section/Home/Validateform'
import Newvalidation from '../../Components/Section/Forms/Newvalidation'
import Contact from '../../Components/Section/Forms/Contact'
// import Registartion from '../../Components/Section/Home/Registration'
// import "./Components/Product"
// import Product from './Components/Product';
// import UseState from './Components/UseState';
// import UseEffect from './Components/UseEffect';
// import UseRef from './Components/UseRef';
// import New from './Components/New';
// import Excontext from './Components/Excontext';
// // import Home from './Pages/Home';
// import Menu from './Mypages/Menu';
// import Postproduct from './Mypages/Postproduct';
// import Addproduct from './Mypages/Addproduct';




const Home = () => {
  return (
    <div>
         {/* <Login/> */}
         {/* <Validateform/> */}
         {/* <Newvalidation/> */}
         <Contact/>
    </div>
  )
}

export default Home
