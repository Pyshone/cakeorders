import React, { Fragment, useState,useEffect} from 'react'

const Menu = () => {
    // const [registrations, setRegistrations]=useState([]);
    const [Table,setTable]=useState([])



useEffect((getResponse)=>{
    getResponse=async()=>{
        fetch("https://dummyjson.com/users")
        .then(res=>res.json())
        .then(data=>{setTable(data)})
        // .catch(error=>{console.log(error);});
    }
},[])




  return (
    <Fragment>
        <div>
      <table style={{width:"100%"}}>
        {/* <thead > */}
            <th align='left'>ID</th>
            <th align='left'>FIRST NAME</th>
            <th align='left'>LAST NAME</th>
            <th align='left'>MIDDLE NAME</th>
            <th align='left'>AGE</th>
            <th align='left'>GENDER</th>
            <th align='left'>EMAIL</th>
            <th align='left'>PHONE</th>
            <th align='left'>USER NAME</th>
            <th align='left'>password</th>
            <th align='left'>birthDate</th>
            <th align='left'>USER NAME</th>
            <th align='left'>height</th>
            <th align='left'>weight</th>

            
        {/* </thead> */}
        <tbody>
            {Table.users?.map((hi)=>
             <tr key={hi.id}>
             <td>{hi.id}
             <img src= {hi.image} style={{width:50,height:50}}/>
             </td>
             <td>{hi.firstName}</td>
             <td>{hi.lastName}</td>
             <td>{hi.maidenName}</td>
             <td>{hi.age}</td>
             <td>{hi.gender}</td>
             <td>{hi.email}</td>
             <td>{hi.phone}</td>
             <td>{hi.username}</td>
             <td>{hi.password}</td>
             <td>{hi.birthDate}</td>
             <td>
                <img src={hi.image} alt=""  style={{width:50,height:50}}/>
             </td>
             <td>{hi.height}</td>
             <td>{hi.weight}</td>
             <td>{hi.birthDate}</td>


         </tr>
         
         )}
           
        </tbody>
      </table>
    </div>
    </Fragment>
  )
}

export default Menu
