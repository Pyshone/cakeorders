import React from "react";
import { useState } from "react";
import { useEffect } from "react";

const UseState = () => {
  const [click, setClick] = useState(0);
//  


//   useEffect(() => {
//     if (click === 500) {
//       alert("You reached 500 clicks!");
//     }
//   }, [click]);

//

  const handleClick = () => {
    const newClick = click + 50;
    setClick(newClick);
    if (newClick === 550) {
      showCustomAlert("You reached 500 clicks! Click OK to reset the count.", resetClick);
    }
  };

  const resetClick = () => {
    setClick(0);
  };

  const showCustomAlert = (message, onOk) => {
    const confirmation = window.confirm(message);
    if (confirmation) {
      onOk();
    }
  };


  return (
      <div className="back">
        {/* <h1>USE STATE</h1>
        <p>UseState is a react hook let add the state varaible in the component and manage and declare in the state manageament in the functional component  like value and setvalue  It provides a way to declare and manage state variables directly within a function component.</p>
          <h3>SYNTAX<br/>const[value,setValue = useState ()]</h3> */}
        <p>You clicked {click} times</p>
        {/* {showAlert && <p>Alert: You reached 500 clicks!</p>} */}
        <button onClick={handleClick} className="btn">CLICK</button>
        {/* <button onClick={() => setClick(click + 100)} className="btn">Click me</button> */}
      </div>
  );
};

export default UseState;
