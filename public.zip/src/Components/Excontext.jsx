import React, { Fragment, useEffect, useState } from 'react';
//  thirtparent imports 

//  images


const Excontext = () => {

    // const {val}=props;

    const [data, setData] = useState(0);
    // const [data,setData]=useState(0);
    // const [data,setData]=useState(0);
    // const [data,setData]=useState(0);
    // const [data,setData]=useState(0);


    const UppendDataId = () => {

    }

    // const UppendDataId =()=>{

    // }

    // const UppendDataId =()=>{

    // }

    // const UppendDataId =()=>{

    // }


    useEffect(() => {

    }, [])

    useEffect(() => {

    }, [])

    useEffect(() => {

    }, [])

    useEffect(() => {

    }, [])

    return (
        <Fragment>
            <div >
                <form action="" className='form-intro'>
                    <label>NAME :</label>
                    <input type="text" placeholder='ENTER YOUR NAME' />
                    <label >PHONE NUMBER :</label>
                    <input placeholder='PHONE NUMBER'/>
                    <label>EMAIL ADDRESS :</label>
                    <input placeholder='YOUR EMAIL ADD' type='email'/>
                    <button type='submit' >SUBMIT</button>
                    {/* onClick={(e) => handelSubmit(e)} */}
                </form>
            </div>
        </Fragment>
    );
}

export default Excontext;
