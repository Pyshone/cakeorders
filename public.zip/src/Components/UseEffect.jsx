import React, { useState,useEffect,useContext} from 'react'
import Context from './Context';


const App = () => {
    const [count, setCount] = useState(false);
    const [calculation, setCalculation] = useState(0);

    useEffect(() => {
      if(count){
        setCount(false);
        setCalculation(calculation + 2);
      }
    }, [count]);
    
  
  return (
    < div className='back'>
    <hr/>
    <p>Count: {calculation} </p>
    <button onClick={() => setCount(true)} className='btn'>+</button>
  </div>
  )
}

export default App
