import React, {useContext}from 'react'
import Context from './Context'

const New= () => {
// const {fruit}=useContext(Context)
const data=useContext(Context)
  return (
  //   <ul>
  //   {fruit.map((fruit,index)=>(
  //     <li key={index}>{fruit}</li>
  // ))}
  // </ul>
  <h1>EveryOne:{data}</h1>
)
}

export default New
