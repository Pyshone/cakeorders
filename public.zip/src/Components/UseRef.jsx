import React, { useRef } from 'react'
import { useState } from 'react';

const UseRef = () => {
    const [counter, setCounter] = useState(0);
    const counterRef = useRef(0)
    const textRef = useRef(0)
    const inputRef = useRef(null);
    const focusPoint = useRef(null);

    const handleClick = () => {
        setCounter(counter + 1);
    };


    const handleRef = () => {
        counterRef.current++
    }
    console.log("iam,always")





    const handleonClick = () => {
        inputRef.current.focus();
    //     focusPoint.current.value = 
    //   "The quick brown fox jumps over the lazy dog"; 
    //   focusPoint.current.focus(); 
      };
    return (
        <>
            {/* <h1>{"counter is ${counter} "}</h1> */}
            <h1>{counter}</h1>
            <h1>{counterRef.current}</h1>
            <button className='btn' onClick={handleClick}>INCREASE-count</button>
            <button className='btn' onClick={handleRef}>INCREASE -ref</button>

            <div>
                <input ref={inputRef} type="text" />
                <button onClick={handleonClick}>wertyuiop</button>
                {/* <textarea ref={focusPoint} />  */}
            </div>
        </>
    )
}
export default UseRef

