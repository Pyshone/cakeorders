import React from 'react'
import { datas } from './map'
import { Grid,Box } from '@mui/material'




const Registartion = () => {
  return (
    <div>
      <h1>Registartion</h1>
      <div>
        <Grid container spacing={3}>
          <Grid item xs={12} md={6} lg={6} >
            <Box sx={{
                display: { xs: 'none', sm: 'block' } 
              }}>
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Enim sed omnis sapiente autem in, labore nobis earum excepturi tenetur dolorum quaerat, voluptate doloribus corporis consequuntur esse odio blanditiis recusandae perferendis?
            </Box>

          </Grid>
          <Grid item xs={12} md={6} lg={6} >
            <Box>
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Enim sed omnis sapiente autem in, labore nobis earum excepturi tenetur dolorum quaerat, voluptate doloribus corporis consequuntur esse odio blanditiis recusandae perferendis?
            </Box>

          </Grid>
        </Grid>
      </div>
      <div>
        {
          datas.map((data,index)=>(
            <ul key={index}>
              <li>{data.id}</li>
              <li>{data.name}</li>
              <li>{data.age}</li>
              <li>{data.DOB}</li>
            </ul>

          )

          )
        }
      </div>
    </div>
  )
}

export default Registartion
