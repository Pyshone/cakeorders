import React, { Fragment, useState } from 'react';
import { Button, Container, Divider, TextField, CircularProgress } from "@mui/material";
import { useForm, useFieldArray } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const schema = yup.object().shape({
    FirstName: yup.string().required("Name is Required")
        .min(4, 'Name must be at least 4 characters long')
        .max(15, 'Name must be at most 15 characters long'),
    LastName: yup.string()
        .required("LastName is Required")
        .min(4, 'LastName must be at least 4 characters long')
        .max(15, 'LastName must be at most 15 characters long'),
    fields: yup.array().of(
        yup.object().shape({
            FirstName: yup.string().required("Name is Required")
                .min(4, 'Name must be at least 4 characters long')
                .max(15, 'Name must be at most 15 characters long'),
            LastName: yup.string().required("LastName is Required")
                .min(4, 'LastName must be at least 4 characters long')
                .max(15, 'LastName must be at most 15 characters long'),
        })
    )
}).required();

const Newvalidation = () => {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const { register, handleSubmit, control, getValues, formState: { errors }, } = useForm({ resolver: yupResolver(schema) });
    const { fields, append, remove } = useFieldArray({ control, name: "fields" });

    const onSubmit = async (data) => {
        setLoading(true);
        try {
            await axios.post('http://localhost:3003/formvalidation', data, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            setLoading(false);
            navigate('/submission');
        } catch (error) {
            console.log(error);
            setLoading(false);
        }
    }

 

    const handleAddClick = () => {
        const currentValues = getValues();
        const isValid = schema.isValidSync(currentValues);
        if (isValid) {
            append({ FirstName: "", LastName: "" , });
            
        }
    }

    return (
        <Fragment>
            <Container maxWidth="lg">
                <div className="form-container">
                    <h2>Multiple Form Submit</h2>
                    <Divider />
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <div className='row'>
                            <div className="column">
                                <TextField label="First Name" placeholder="Enter First Name" {...register("FirstName")} />
                                <p className="error">{errors.FirstName?.message}</p>
                            </div>
                            <div className="column">
                                <TextField label="Last Name" placeholder="Enter Last Name" {...register("LastName")} />
                                <p className="error">{errors.LastName?.message}</p>
                            </div>
                            <div className="column">
                                <input type="file" {...register("image")} accept="image/*" />
                          
                            </div>
                            <div >
                                <Button variant="contained" color="error" type="button" onClick={handleAddClick}>
                                    {loading ? <CircularProgress size={24} /> : "Add"}
                                </Button>
                            </div>
                        </div>
                        <Divider />
                        <div>
                            {fields.map((field, index) => (
                                <div key={index} className='row'>
                                    <div className="column">
                                        <TextField label="First Name" placeholder="Enter First Name" {...register(`fields.${index}.FirstName`)} defaultValue={field.FirstName} />
                                        <p className="error">{errors.fields?.[index]?.FirstName?.message}</p>
                                    </div>
                                    <div className="column">
                                        <TextField label="Last Name" placeholder="Enter Last Name" {...register(`fields.${index}.LastName`)} defaultValue={field.LastName} />
                                        <p className="error">{errors.fields?.[index]?.LastName?.message}</p>
                                    </div>
                                    <div className="column">
                                        <input type="file" {...register(`fields.${index}.image`)} accept="image/*" />
                                    </div>
                                    
                                    <div className="button-container">
                                    <Button variant="contained" color="error" type="button" onClick={handleAddClick}>
                                    {loading ? <CircularProgress size={24} /> : "Add"}
                                </Button>
                                        <Button variant="contained" color="secondary" onClick={() => remove(index)}>Remove</Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <Button type="submit" variant='contained' color='success'>Submit</Button>
                    </form>
                </div>
            </Container>
        </Fragment>
    )
}

export default Newvalidation;
// import React, { Fragment, useState } from 'react';
// import { Button, Container, Divider, TextField, CircularProgress } from "@mui/material";
// import { useForm, useFieldArray } from "react-hook-form";
// import { yupResolver } from "@hookform/resolvers/yup";
// import * as yup from "yup";
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';

// const schema = yup.object().shape({
//     FirstName: yup.string().required("Name is Required")
//         .min(4, 'Name must be at least 4 characters long')
//         .max(15, 'Name must be at most 15 characters long'),
//     LastName: yup.string()
//         .required("LastName is Required")
//         .min(4, 'LastName must be at least 4 characters long')
//         .max(15, 'LastName must be at most 15 characters long'),
//     fields: yup.array().of(
//         yup.object().shape({
//             FirstName: yup.string().required("Name is Required")
//                 .min(4, 'Name must be at least 4 characters long')
//                 .max(15, 'Name must be at most 15 characters long'),
//             LastName: yup.string().required("LastName is Required")
//                 .min(4, 'LastName must be at least 4 characters long')
//                 .max(15, 'LastName must be at most 15 characters long'),
//         })
//     )
// }).required();

// const Newvalidation = () => {
//     const navigate = useNavigate();
//     const [loading, setLoading] = useState(false);
//     const { register, handleSubmit, control, getValues, setValue, formState: { errors }, } = useForm({ resolver: yupResolver(schema) });
//     const { fields, append, remove } = useFieldArray({ control, name: "fields" });

//     const [file, setFile] = useState();
//     const [filePreviews, setFilePreviews] = useState([]);

//     const handleImageChange = (e, index) => {
//         const file = e.target.files[0];
//         if (index >= 0) {
//             const updatedPreviews = [...filePreviews];
//             updatedPreviews[index] = URL.createObjectURL(file);
//             setFilePreviews(updatedPreviews);
//             setValue(`fields.${index}.image`, file);
//         } else {
//             setFile(URL.createObjectURL(file));
//             setValue("image", file);
//         }
//     };

//     const onSubmit = async (data) => {
//         setLoading(true);

//         const formData = new FormData();
//         formData.append("FirstName", data.FirstName);
//         formData.append("LastName", data.LastName);
//         if (data.image) {
//             formData.append("image", data.image);
//         }

//         data.fields.forEach((field, index) => {
//             formData.append(`fields[${index}][FirstName]`, field.FirstName);
//             formData.append(`fields[${index}][LastName]`, field.LastName);
//             if (field.image) {
//                 formData.append(`fields[${index}][image]`, field.image);
//             }
//         });

//         try {
//             await axios.post('http://localhost:3003/formvalidation', formData, {
//                 headers: {
//                     'Content-Type': 'multipart/form-data'
//                 }
//             });
//             setLoading(false);
//             navigate('/submission');
//         } catch (error) {
//             console.log(error);
//             setLoading(false);
//         }
//     }

//     const handleAddClick = () => {
//         const currentValues = getValues();
//         const isValid = schema.isValidSync(currentValues);
//         if (isValid) {
//             append({ FirstName: "", LastName: "", image: null });
//             setFilePreviews([...filePreviews, null]);
//         }
//     }

//     return (
//         <Fragment>
//             <Container maxWidth="lg">
//                 <div className="form-container">
//                     <h2>Multiple Form Submit</h2>
//                     <Divider />
//                     <form onSubmit={handleSubmit(onSubmit)}>
//                         <div className='row'>
//                             <div className="column">
//                                 <TextField label="First Name" placeholder="Enter First Name" {...register("FirstName")} />
//                                 <p className="error">{errors.FirstName?.message}</p>
//                             </div>
//                             <div className="column">
//                                 <TextField label="Last Name" placeholder="Enter Last Name" {...register("LastName")} />
//                                 <p className="error">{errors.LastName?.message}</p>
//                             </div>
//                             <div className="column">
//                                 <input type="file" onChange={(e) => handleImageChange(e, -1)} accept="image/*" />
//                                 {file && <img src={file} alt="Preview" width="100" />}
//                             </div>
//                             <div >
//                                 <Button variant="contained" color="error" type="button" onClick={handleAddClick}>
//                                     {loading ? <CircularProgress size={24} /> : "Add"}
//                                 </Button>
//                             </div>
//                         </div>
//                         <Divider />
//                         <div>
//                             {fields.map((field, index) => (
//                                 <div key={index} className='row'>
//                                     <div className="column">
//                                         <TextField label="First Name" placeholder="Enter First Name" {...register(`fields.${index}.FirstName`)} defaultValue={field.FirstName} />
//                                         <p className="error">{errors.fields?.[index]?.FirstName?.message}</p>
//                                     </div>
//                                     <div className="column">
//                                         <TextField label="Last Name" placeholder="Enter Last Name" {...register(`fields.${index}.LastName`)} defaultValue={field.LastName} />
//                                         <p className="error">{errors.fields?.[index]?.LastName?.message}</p>
//                                     </div>
//                                     <div className="column">
//                                         <input type="file" onChange={(e) => handleImageChange(e, index)} accept="image/*" />
//                                         {filePreviews[index] && <img src={filePreviews[index]} alt="Preview" width="100" />}
//                                     </div>
//                                     <div className="button-container">
//                                         <Button variant="contained" color="secondary" onClick={() => remove(index)}>Remove</Button>
//                                     </div>
//                                 </div>
//                             ))}
//                         </div>
//                         <Button type="submit" variant='contained' color='success'>Submit</Button>
//                     </form>
//                 </div>
//             </Container>
//         </Fragment>
//     )
// }

// export default Newvalidation;
