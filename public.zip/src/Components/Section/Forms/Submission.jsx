import React, { useState, useEffect, Fragment } from 'react';
import axios from 'axios';

const Submission = () => {
  const [data, setData] = useState([]); 

  // Function to fetch data from the API
  const getResponse = async () => {
    try {
      const response = await axios.get("http://localhost:3003/formvalidation");
      setData(response.data); 
    } catch (error) {
      console.error(error);
    }
  };

  // Function to delete a main entry
  const deleteEntry = async (id) => {
    if (window.confirm('Are you sure you want to delete this entry?')) {
      try {
        await axios.delete(`http://localhost:3003/formvalidation/${id}`);
        getResponse(); 
      } catch (error) {
        console.error(error);
      }
    }
  };

  useEffect(() => {
    getResponse();
  }, []);

  return (
    <Fragment>
      <h2>Data Table</h2>
      <table style={{ width: "100%" }}>
        <thead>
          <tr>
            <th align="left">First Name</th>
            <th align="left">Last Name</th>
            <th align="left">Images</th>
            <th align="left">Actions</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item) => (
            <tr key={item.id}>
              <td>{item.FirstName}</td>
              <td>{item.LastName}</td>
              <td>
                {item.image && item.image.length > 0 ? (
                  item.image.map((imgUrl, index) => (
                    <img key={index} src={imgUrl} alt={`Profile ${index}`} width="50" />
                  ))
                ) : 'No Image'}
              </td>
              <td>
                <button onClick={() => deleteEntry(item.id)}>Delete Entry</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </Fragment>
  );
};

export default Submission;
