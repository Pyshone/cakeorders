import React from "react";
import { useState } from "react";

const Product = (props) => {
  return (
    <>
      <div>
        <h2>Hello PROPS {props.user}</h2>
        <h3>Welcome to GeeksforGeeks  {props.user}</h3>
        <h4> {props.user}</h4>
      </div>
    </>
  );
};

export default Product;
// import logo from './logo.svg';
// import './App.css';
// import "./Components/Product"
// import Product from './Components/Product';
// import UseState from './Components/UseState';
// import UseEffect from './Components/UseEffect';
// import UseRef from './Components/UseRef';
// import { createContext, useState } from 'react';
// import UseContext from './Components/UseContext';
// import Excontext from './Components/Excontext';


// // export const MyContext=createContext(null);



// const [authstatus, setauthstatus] = useState(false);
// const login = () => {
//   setauthstatus(true);
// };

// function App() { 
// const [name,setName] =useState("")

//   return (

//   <div>
//     <MyContext.Provider>
//       <Excontext/>
//       <br></br>
//       <UseContext/>
//     </MyContext.Provider>
//   </div>

//     //   <>
//   // {/* <Product user="happy to see All"/> */}
//   // <UseState/>
//   // <UseEffect/>
//   // <UseRef/>
//   //   </>
//   );
// }

// export default App;
