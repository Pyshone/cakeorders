import "./App.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { Suspense, lazy } from "react";

const Home = lazy(() => import("../src/Views/App/Home"));
const Registartion = lazy(() =>import("./Components/Section/Home/Registartion"));
const Other = lazy (()=> import ("./Components/Section/Home/Other"))
const Validateform = lazy (()=>import  ("./Components/Section/Home/Validateform"))
const Submission = lazy (()=> import("./Components/Section/Forms/Submission"))
const CakeContact = lazy (()=> import("./Components/Section/Forms/CakeContact"))

function App() {
  return (
    <>
      <Router>
        <Suspense fallback={<h1 style={{ fontSize: "50px" }}>Loading...</h1>}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/registartion" element={<Registartion />} />
            <Route path="/other" element={<Other/>} />
            <Route path="/validate" element={<Validateform/>} />
            <Route path="/submission" element={<Submission/>}/>
            <Route path="/orderlist" element={<CakeContact/>}/>
          </Routes>
        </Suspense>
      </Router>
    </>
  );
}

export default App;
